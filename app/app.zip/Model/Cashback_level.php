<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class cashback_level extends Model
{
    protected $guarded = ['id'];
}
